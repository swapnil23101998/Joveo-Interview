 
export const data = [
    {
        id: 1,
        name: 'root',
        type: 'folder',
        items: [
            {
                id: 2,
                name: 'folder_1_root',
                type: 'folder',
                items: [
                        {
    
                            id: 3,
                            name: 'file_1_folder1',
                            type: 'file'
    
                        }
                ]
            },
            {
                id: 4,
                name: 'folder_2_root',
                type: 'folder',
                items: [
                        {
    
                            id: 5,
                            name: 'file_1_folder2',
                            type: 'file'
    
                        }
                ]
            },
            {
                id: 6,
                name: 'file_1_root',
                type: 'file'
            }
        ]
    }
]